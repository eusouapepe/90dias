# Planner Universo Exponencial - 90 Dias
### Versão Final - Campos Amarelos + Parser Automático + Copiar Prompt

Planner premium editorial para transformar experiência em autoridade percebida.

## ✨ O que tem nesta versão final

- **Campos em amarelo (#FEF9C2)** - NOME (em branco), INSTAGRAM, NICHO, META, PÚBLICO-ALVO, 5 ASSUNTOS - todos editáveis com selo EDITÁVEL
- **Prompt dinâmico corrigido** - Nome fixo Maria Fernanda Vergotti no template, mas campo em branco para pessoa preencher. Placeholders [INSTAGRAM], [NICHO] etc são substituídos em tempo real. Botão COPIAR PROMPT com fallback robusto funcionando 100%
- **Colar resposta da IA** - Textarea + botão PREENCHER AUTOMATICAMENTE que extrai dia - data - territorio editorial - título - gancho - formato sugerido - categoria - esqueleto para roteiro
- **Progresso 90 dias** - Tabela com bolinhas clicáveis, barra X/90
- **13 semanas completas** - SEM 01 a SEM 13 sem pular (01-07, 08-14, 15-21, 22-28, 29-35, 36-42, 43-49, 50-56, 57-63, 64-70, 71-77, 78-84, 85-90)
- **Apenas roteiros** - Seção dos 10 territórios removida conforme solicitado

## 🚀 Como usar

1. Abra `index.html`
2. Preencha os campos amarelos
3. Clique em COPIAR PROMPT COMPLETO
4. Cole no ChatGPT e gere
5. Cole resposta de volta no planner e clique em PREENCHER AUTOMATICAMENTE

## 🎨 Design

- Paleta: navy #0F1E2E, off-white #F8F3EC, areia #E8DCCF, terracota #D9B8A5, sage #C7D9D1, dourado #E7D49E
- Fontes: Playfair Display + Inter
- Estilo: quiet luxury editorial

## 📦 Deploy

```bash
git init
git add .
git commit -m "feat: v-final campos amarelos + copiar prompt fix"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/planner-universo.git
git push -u origin main
```

Vercel: importe o repo e deploy automático.

---
Feito com @eusouapepe_ | Universo Exponencial
